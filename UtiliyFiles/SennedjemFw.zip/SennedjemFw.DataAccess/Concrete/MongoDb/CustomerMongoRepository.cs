﻿using Core.$safeprojectname$.MongoDb.Abstract;
using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.MongoDb.Context;
using Entities.Concrete;

namespace $safeprojectname$.Concrete.MongoDb
{
    public class CustomerMongoRepository : MongoDbRepositoryBase<Customer>, ICustomerRepository
    {
        public CustomerMongoRepository(MongoDbContextBase mongoDbContext, string collectionName) : base(mongoDbContext.mongoConnectionSettings, collectionName)
        {

        }

    }
}
