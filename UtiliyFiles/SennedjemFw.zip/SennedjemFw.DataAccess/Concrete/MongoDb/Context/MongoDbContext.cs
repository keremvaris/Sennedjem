﻿using Core.$safeprojectname$.MongoDb.Concrete.Models;
using Microsoft.Extensions.Configuration;

namespace $safeprojectname$.Concrete.MongoDb.Context
{

    public class MongoDbContext : MongoDbContextBase
    {
        public MongoDbContext(IConfiguration configuration) : base(configuration)
        {

        }

    }
}
