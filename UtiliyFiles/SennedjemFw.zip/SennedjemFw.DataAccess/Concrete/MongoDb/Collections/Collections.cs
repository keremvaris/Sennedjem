﻿namespace $safeprojectname$.Concrete.MongoDb.Collections
{
    public static class Collections
    {
        public static string Customers => "customers";
    }
}
