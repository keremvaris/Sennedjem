﻿using Core.Entities.Concrete;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace $safeprojectname$.Concrete.Configurations
{
  public class GroupEntityConfiguration : IEntityTypeConfiguration<Group>
  {
    public void Configure(EntityTypeBuilder<Group> builder)
    {
      builder.HasKey(x => x.Id);
      builder.Property(x => x.GroupName).HasMaxLength(50).IsRequired();
    }
  }
}
