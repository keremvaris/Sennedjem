﻿using Core.Entities.Concrete;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace $safeprojectname$.Concrete.Configurations
{
  public class OperationClaimEntityConfiguration : IEntityTypeConfiguration<OperationClaim>
  {
    public void Configure(EntityTypeBuilder<OperationClaim> builder)
    {
      builder.HasKey(x => x.Id);
      builder.Property(x => x.Name).HasMaxLength(50).IsRequired();
    }
  }
}
