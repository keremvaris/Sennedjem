﻿using Core.$safeprojectname$.EntityFramework;
using Core.Entities.Concrete;
using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.EntityFramework.Contexts;

namespace $safeprojectname$.Concrete.EntityFramework
{
  public class UserGroupRepository : EfEntityRepositoryBase<UserGroup, ProjectDbContext>, IUserGroupRepository
  {
    public UserGroupRepository(ProjectDbContext context) : base(context)
    {
    }
  }
}
