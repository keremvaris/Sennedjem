﻿using Core.$safeprojectname$.EntityFramework;
using Core.Entities.Concrete;
using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.EntityFramework.Contexts;

namespace $safeprojectname$.Concrete.EntityFramework
{
  public class GroupRepository : EfEntityRepositoryBase<Group, ProjectDbContext>, IGroupRepository
  {
    public GroupRepository(ProjectDbContext context) : base(context)
    {
    }
  }
}
