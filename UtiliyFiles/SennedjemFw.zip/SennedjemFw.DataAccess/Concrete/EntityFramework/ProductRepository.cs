﻿
using System;
using System.Linq;
using Core.$safeprojectname$.EntityFramework;
using Entities.Concrete;
using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.EntityFramework.Contexts;

namespace $safeprojectname$.Concrete.EntityFramework
{
    public class ProductRepository : EfEntityRepositoryBase<Product, ProjectDbContext>, IProductRepository
    {
        public ProductRepository(ProjectDbContext context) : base(context)
        {
        }
    }
}
