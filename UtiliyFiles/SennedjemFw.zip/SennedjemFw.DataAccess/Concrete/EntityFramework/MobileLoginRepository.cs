﻿using Core.$safeprojectname$.EntityFramework;
using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.EntityFramework.Contexts;
using $safeprojectname$.Entities;

namespace $safeprojectname$.Concrete.EntityFramework
{
  public class MobileLoginRepository : EfEntityRepositoryBase<MobileLogin, ProjectDbContext>, IMobileLoginRepository
  {
    public MobileLoginRepository(ProjectDbContext context) : base(context)
    {
    }
  }
}
