﻿
using System;
using System.Linq;
using Core.$safeprojectname$.EntityFramework;
using Entities.Concrete;
using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.EntityFramework.Contexts;

namespace $safeprojectname$.Concrete.EntityFramework
{
    public class AnimalRepository : EfEntityRepositoryBase<Animal, ProjectDbContext>, IAnimalRepository
    {
        public AnimalRepository(ProjectDbContext context) : base(context)
        {
        }
    }
}
