﻿using Core.$safeprojectname$.MongoDb.Abstract;
using Entities.Concrete;


namespace $safeprojectname$.Abstract
{
    public interface ICustomerRepository : IMongoDbRepository<Customer>
    {

    }
}
