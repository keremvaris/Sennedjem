﻿
using System;
using Core.$safeprojectname$;
using Entities.Concrete;
namespace $safeprojectname$.Abstract
{
    public interface ICarRepository : IEntityRepository<Car>
    {
    }
}