﻿using Core.$safeprojectname$;
using Core.Entities.Concrete;

namespace $safeprojectname$.Abstract
{
  public interface IOperationClaimRepository : IEntityRepository<OperationClaim>
  {
  }
}
