﻿using Core.$safeprojectname$;
using $safeprojectname$.Entities;
namespace $safeprojectname$.Abstract
{
	public interface IMobileLoginRepository : IEntityRepository<MobileLogin>
	{
	}
}