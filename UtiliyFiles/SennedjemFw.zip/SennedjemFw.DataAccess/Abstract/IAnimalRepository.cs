﻿
using System;
using Core.$safeprojectname$;
using Entities.Concrete;
namespace $safeprojectname$.Abstract
{
    public interface IAnimalRepository : IEntityRepository<Animal>
    {
    }
}