﻿using Castle.DynamicProxy;
using $safeprojectname$.Utilities.Interceptors;
using System.Transactions;

namespace $safeprojectname$.Aspects.Autofac.Transaction
{
    /// <summary>
    /// TransactionScopeAspect
    /// </summary>
    public class TransactionScopeAspect : MethodInterception
    {
        public override void Intercept(IInvocation invocation)
        {
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    invocation.Proceed();
                    transactionScope.Complete();
                }
                catch (System.Exception ex)
                {
                    ex.ToString();
                    throw;
                }
            }
        }
    }
}
