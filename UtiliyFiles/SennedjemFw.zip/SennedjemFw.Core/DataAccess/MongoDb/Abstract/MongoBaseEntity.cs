﻿using MongoDB.Bson;

namespace $safeprojectname$.DataAccess.MongoDb.Abstract
{
    public abstract class MongoBaseEntity
    {
        public ObjectId Id { get; set; }
    }
}
