﻿using $safeprojectname$.Entities;
using System.Linq;

namespace $safeprojectname$.DataAccess
{
    public interface IQueryableRepositoryBase<out T> where T : class, IEntity, new()
    {
        IQueryable<T> Table { get; }
    }
}
