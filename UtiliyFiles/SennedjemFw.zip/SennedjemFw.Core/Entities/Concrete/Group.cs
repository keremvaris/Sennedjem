﻿namespace $safeprojectname$.Entities.Concrete
{
  public class Group : IEntity
  {
    public int Id { get; set; }
    public string GroupName { get; set; }

  }
}
