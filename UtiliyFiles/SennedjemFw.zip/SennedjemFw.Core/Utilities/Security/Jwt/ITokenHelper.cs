﻿using System.Collections.Generic;
using $safeprojectname$.Entities.Concrete;

namespace $safeprojectname$.Utilities.Security.Jwt
{
    public interface ITokenHelper
    {
        TAccessToken CreateToken<TAccessToken>(User user, IEnumerable<OperationClaim> operationClaims)
          where TAccessToken : IAccessToken, new();
    }
}
