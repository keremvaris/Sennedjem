﻿namespace $safeprojectname$.Utilities.MessageBrokers.RabbitMq
{
  public interface IMessageConsumer
  {
    void GetQueue();
  }
}
