﻿using System;

namespace $safeprojectname$.Utilities.IoC
{
    public static class ServiceTool
    {
        public static IServiceProvider ServiceProvider { get; set; }
    }
}
