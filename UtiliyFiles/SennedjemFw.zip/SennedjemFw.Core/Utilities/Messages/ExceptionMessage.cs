﻿namespace $safeprojectname$.Utilities.Messages
{
    public static class ExceptionMessage
    {
        public static string InternalServerError => "Bir hata oluştu. Lütfen tekrar deneyiniz.";
    }
}
