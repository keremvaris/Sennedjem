﻿namespace $safeprojectname$.Utilities.Messages
{
    public static class SerilogMessages
    {
        public static string NullOptionsMessage => "Boş bir değer gönderdiniz! Bir hata oluştu. Lütfen tekrar deneyiniz.";
    }
}
