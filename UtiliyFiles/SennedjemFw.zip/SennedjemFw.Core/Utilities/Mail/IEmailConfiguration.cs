﻿namespace $safeprojectname$.Utilities.Mail
{
  public interface IEmailConfiguration
  {
    string SmtpServer { get; }
    int SmtpPort { get; }
    string SmtpUserName { get; }
    string Password { get; }
  }
}
