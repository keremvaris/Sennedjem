﻿namespace $safeprojectname$.CrossCuttingConcerns.Logging.Serilog.ConfigurationModels
{
    public class PostgreConfiguration
    {
        public string ConnectionString { get; set; }
    }
}
