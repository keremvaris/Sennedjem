﻿namespace $safeprojectname$.CrossCuttingConcerns.Logging.Serilog.ConfigurationModels
{
    public class MSTeamsConfiguration
    {
        public string ChannelHookAdress { get; set; }
    }
}
