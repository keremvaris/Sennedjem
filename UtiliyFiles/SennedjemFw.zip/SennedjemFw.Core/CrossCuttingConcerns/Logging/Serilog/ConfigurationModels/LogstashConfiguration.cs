﻿namespace $safeprojectname$.CrossCuttingConcerns.Logging.Serilog.ConfigurationModels
{
    public class LogstashConfiguration
    {
        public string URL { get; set; }
    }
}
