﻿namespace $safeprojectname$.CrossCuttingConcerns.Logging.NLog.Loggers
{
    public class FileLogger : LoggerServiceBase
    {
        public FileLogger() : base("JsonFileLogger")
        {

        }
    }
}
