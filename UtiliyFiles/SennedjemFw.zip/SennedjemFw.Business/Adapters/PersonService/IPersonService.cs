﻿using System.Threading.Tasks;

namespace $safeprojectname$.Adapters.PersonService
{
    public interface IPersonService
    {
        Task<bool> VerifyCid(long tCKimlikNo, string ad, string soyad, int dogumYili);
    }
}
