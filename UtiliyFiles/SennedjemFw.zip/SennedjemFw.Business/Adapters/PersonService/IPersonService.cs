﻿using System.Threading.Tasks;

namespace $safeprojectname$.Adapters.PersonService
{
    public interface IPersonService
    {
        Task<bool> VerifyCid(long TCKimlikNo, string Ad, string Soyad, int DogumYili);
    }
}
