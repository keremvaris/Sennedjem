﻿using Autofac;
using Autofac.Extras.DynamicProxy;
using Castle.DynamicProxy;
using Core.Utilities.Interceptors;
using FluentValidation;
using MediatR;

namespace $safeprojectname$.DependencyResolvers
{
    public class AutofacBusinessModule : Module
    {
        private readonly ConfigurationManager configuration;

        /// <summary>
        /// Autofac icin.
        /// </summary>
        public AutofacBusinessModule()
        {
        }

        public AutofacBusinessModule(ConfigurationManager configuration)
        {
            this.configuration = configuration;
        }

        /// <summary>
        /// </summary>
        /// <param name="builder"></param>
        protected override void Load(ContainerBuilder builder)
        {

            var assembly = System.Reflection.Assembly.GetExecutingAssembly();


            builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()

                    .AsClosedTypesOf(typeof(IRequestHandler<,>));

            builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()
                .AsClosedTypesOf(typeof(IValidator<>));

            switch (configuration.Mode)
            {
                case ApplicationMode.Development:
                    builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()

                            .Where(t => t.FullName.StartsWith("$safeprojectname$.Fakes"))
                            ;
                    break;
                case ApplicationMode.Profiling:

                    builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()

                            .Where(t => t.FullName.StartsWith("$safeprojectname$.Fakes.SmsService") ||
                            t.FullName.StartsWith("$safeprojectname$.Fakes.BloodTeamService"))
                            ;
                    break;
                case ApplicationMode.Staging:

                    builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()

                            .Where(t => t.FullName.StartsWith("$safeprojectname$.Fakes.SmsService") ||
                            t.FullName.StartsWith("$safeprojectname$.Fakes.BloodTeamService"))
                            ;
                    break;
                case ApplicationMode.Production:

                    builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()

                                    .Where(t => t.FullName.StartsWith("$safeprojectname$.Adapters"))
                                    ;
                    break;
                default:
                    break;
            }

            builder.RegisterAssemblyTypes(assembly).AsImplementedInterfaces()
                .EnableInterfaceInterceptors(new ProxyGenerationOptions()
                {
                    Selector = new AspectInterceptorSelector()
                }).SingleInstance();
        }
    }
}

