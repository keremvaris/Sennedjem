﻿using DataAccess.Entities;

namespace $safeprojectname$.Services.Authentication
{
	public interface IAuthenticationCoordinator
	{
		IAuthenticationProvider SelectProvider(AuthenticationProviderType type);
	}
}