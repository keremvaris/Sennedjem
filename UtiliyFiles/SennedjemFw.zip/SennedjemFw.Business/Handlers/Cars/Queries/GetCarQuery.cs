﻿
using $safeprojectname$.BusinessAspects;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Handlers.Cars.Queries
{
    [SecuredOperation]
    public class GetCarQuery : IRequest<IDataResult<Car>>
    {
        public int CarId { get; set; }

        class GetCarQueryHandler : IRequestHandler<GetCarQuery, IDataResult<Car>>
        {
            private readonly ICarRepository _carRepository;

            public GetCarQueryHandler(ICarRepository carRepository)
            {
                _carRepository = carRepository;
            }

            public async Task<IDataResult<Car>> Handle(GetCarQuery request, CancellationToken cancellationToken)
            {
                var car = await _carRepository.GetAsync(p => p.CarId == request.CarId);
                return new SuccessDataResult<Car>(car);
            }
        }
    }
}
