﻿
using $safeprojectname$.BusinessAspects;
using Core.Aspects.Autofac.Performance;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using MediatR;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$.Handlers.Cars.Queries
{
    [SecuredOperation]
    public class GetCarsQuery : IRequest<IDataResult<IEnumerable<Car>>>
    {
        public class GetCarsQueryHandler : IRequestHandler<GetCarsQuery, IDataResult<IEnumerable<Car>>>
        {
            private readonly ICarRepository _carRepository;

            public GetCarsQueryHandler(ICarRepository carRepository)
            {
                _carRepository = carRepository;
            }

            [PerformanceAspect(5)]
            //[CacheAspect(10)]
            public async Task<IDataResult<IEnumerable<Car>>> Handle(GetCarsQuery request, CancellationToken cancellationToken)
            {
                return new SuccessDataResult<IEnumerable<Car>>(await _carRepository.GetListAsync());
            }
        }
    }
}