﻿
using $safeprojectname$.BusinessAspects;
using $safeprojectname$.Constants;
using $safeprojectname$.ValidationRules.FluentValidation;
using Core.Aspects.Autofac.Caching;
using Core.Aspects.Autofac.Logging;
using Core.Aspects.Autofac.Validation;
using Core.CrossCuttingConcerns.Logging.NLog.Loggers;
using Core.Utilities.Results;
using DataAccess.Abstract;
using Entities.Concrete;
using MediatR;
using System.Threading;
using System.Threading.Tasks;


namespace $safeprojectname$.Handlers.Cars.Commands
{
    /// <summary>
    /// 
    /// </summary>
    [SecuredOperation]
    public class CreateCarCommand : IRequest<IResult>
    {
        ///Request'ten gelecek değerler buraya yazılır. Örneğin:

        public string CarName { get; set; }

        public class CreateCarCommandHandler : IRequestHandler<CreateCarCommand, IResult>
        {
            private readonly ICarRepository _carRepository;

            public CreateCarCommandHandler(ICarRepository carRepository)
            {
                _carRepository = carRepository;
            }
            /// <summary>
            ///            
            /// </summary>
            /// <param name="request"></param>
            /// <param name="cancellationToken"></param>
            /// <returns></returns>
            [ValidationAspect(typeof(CreateCarValidator), Priority = 1)]
            [CacheRemoveAspect("Get")]
            [LogAspect(typeof(FileLogger))]
            public async Task<IResult> Handle(CreateCarCommand request, CancellationToken cancellationToken)
            {
                var isCarExits = await _carRepository.GetAsync(u => u.CarName == request.CarName);

                if (isCarExits != null)
                    return new ErrorResult(Messages.NameAlreadyExist);



                _carRepository.Add(isCarExits);
                await _carRepository.SaveChangesAsync();
                return new SuccessResult(Messages.Added);
            }
        }
    }
}