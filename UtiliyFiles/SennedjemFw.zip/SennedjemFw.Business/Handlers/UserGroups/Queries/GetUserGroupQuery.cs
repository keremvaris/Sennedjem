﻿namespace $safeprojectname$.Handlers.UserGroups.Queries
{
    class GetUserGroupQuery
    {
    }
}
