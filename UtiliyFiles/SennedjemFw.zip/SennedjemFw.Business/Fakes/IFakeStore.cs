﻿using System.Collections.Generic;

namespace $safeprojectname$.Fakes
{
	public interface IFakeStore
	{
		List<TEntity> Set<TEntity>();
	}
}