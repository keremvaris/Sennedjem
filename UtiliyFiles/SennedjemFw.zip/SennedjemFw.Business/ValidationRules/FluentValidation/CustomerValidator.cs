﻿using $safeprojectname$.Handlers.Customers.Commands;
using FluentValidation;

namespace $safeprojectname$.ValidationRules.FluentValidation
{
    public class CreateCustomerValidator:AbstractValidator<UpdateCustomerCommand>
    {
        public CreateCustomerValidator()
        {
            RuleFor(x => x.Username).NotNull().NotEmpty();
        }
    }

    public class UpdateCustomerValidator : AbstractValidator<UpdateCustomerCommand>
    {
        public UpdateCustomerValidator()
        {
            RuleFor(x => x.Username).NotNull().NotEmpty();
        }
    }
}
