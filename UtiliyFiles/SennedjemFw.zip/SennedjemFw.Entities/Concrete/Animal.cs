﻿using Core.$safeprojectname$;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Concrete
{
    public class Animal : IEntity
    {
        public int AnimalId { get; set; }
        public string AnimalName { get; set; }
    }
}
