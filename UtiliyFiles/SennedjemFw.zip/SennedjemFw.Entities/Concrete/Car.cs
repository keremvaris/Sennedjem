﻿using Core.$safeprojectname$;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Concrete
{
    public class Car : IEntity
    {
        public int CarId { get; set; }
        public int CarName { get; set; }
    }
}
