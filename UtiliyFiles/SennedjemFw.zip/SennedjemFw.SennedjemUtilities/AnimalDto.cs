﻿namespace $safeprojectname$
{
    public class AnimalDto
    {
        public string AnimalName { get; set; }
    }
}

