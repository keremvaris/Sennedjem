﻿using Entities.Concrete;
using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public interface IAnimalDataService
    {
        [Get("/api/Animals/getall")]
        Task<List<Animal>> GetAnimals();
    }
}
